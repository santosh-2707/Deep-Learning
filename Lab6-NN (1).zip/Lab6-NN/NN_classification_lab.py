"""
Classification Lab: learning to classify 2D data points by NN
06/03/2021 tested on PyTorch 1.8.1
This code is modified from https://github.com/MorvanZhou/PyTorch-Tutorial/blob/master/tutorial-contents/302_classification.py

Dependencies:
torch: 0.4
numpy
matplotlib
"""
# Question1: what is the network structure? Uncomment Line59 # print(net)  to view the net architecture
# Question2: What is the input and output of the network?
# Question3: When the output is normalized as probability by softmax?
# To-do: If we add another 2 hidden layers (named hidden2, hidden3) after the first one in the NN, how to modify the code?



import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt

# torch.manual_seed(1)    # reproducible

# make fake data for training by normal distribution (mean, std)
n_data = torch.ones(1000, 2)
x0 = torch.normal(2*n_data, 1)      # class0 x data (tensor), shape=(1000, 2)
y0 = torch.zeros(1000)               # class0 y data (tensor), shape=(1000, 1)
x1 = torch.normal(-2*n_data, 1)     # class1 x data (tensor), shape=(1000, 2)
y1 = torch.ones(1000)                # class1 y data (tensor), shape=(1000, 1)
x = torch.cat((x0, x1), 0).type(torch.FloatTensor)  # shape (2000, 2) FloatTensor = 32-bit floating
y = torch.cat((y0, y1), ).type(torch.LongTensor)    # shape (2000,) LongTensor = 64-bit integer

# make fake data for testing by normal distribution (mean, std)
t_x0 = torch.normal(1*n_data, 1)      # class0 x data (tensor), shape=(1000, 2)
t_y0 = torch.zeros(1000)               # class0 y data (tensor), shape=(1000, 1)
t_x1 = torch.normal(-1*n_data, 1)     # class1 x data (tensor), shape=(1000, 2)
t_y1 = torch.ones(1000)                # class1 y data (tensor), shape=(1000, 1)
t_x = torch.cat((t_x0, t_x1), 0).type(torch.FloatTensor)  # shape (2000, 2) FloatTensor = 32-bit floating
t_y = torch.cat((t_y0, t_y1), ).type(torch.LongTensor)    # shape (2000,) LongTensor = 64-bit integer


# The code below is deprecated in Pytorch 0.4. Now, autograd directly supports tensors
# x, y = Variable(x), Variable(y)
# plt.scatter(x.data.numpy()[:, 0], x.data.numpy()[:, 1], c=y.data.numpy(), s=100, lw=0, cmap='RdYlGn')
# plt.show()

class Net(torch.nn.Module):
    def __init__(self, n_feature, n_hidden, n_output):
        super(Net, self).__init__()
        self.hidden = torch.nn.Linear(n_feature, n_hidden)   # 1st hidden layer
        self.out = torch.nn.Linear(n_hidden, n_output)   # output layer

    def forward(self, x):
        x = F.relu(self.hidden(x))      # activation function for hidden layer
        x = self.out(x)
        return x

net = Net(n_feature=2, n_hidden=10, n_output=2)     # define the network
# print(net)  # net architecture

optimizer = torch.optim.SGD(net.parameters(), lr=0.02)
loss_func = torch.nn.CrossEntropyLoss()  # the target label is NOT an one-hotted

plt.ion()   # something about plotting

for t in range(201):
    out = net(x)                 # input x and predict based on x
    loss = loss_func(out, y)     # must be (1. nn output, 2. target), the target label is NOT one-hotted

    optimizer.zero_grad()   # clear gradients for next train
    loss.backward()         # backpropagation, compute gradients
    optimizer.step()        # apply gradients

    if t % 2 == 0:
        # perform testing and evaluation during the learning process
        plt.cla()
        t_out = net(t_x)
        prediction = torch.max(t_out, 1)[1]
        pred_y = prediction.data.numpy()
        target_y = t_y.data.numpy()
        plt.scatter(t_x.data.numpy()[:, 0], t_x.data.numpy()[:, 1], c=pred_y, s=100, lw=0, cmap='RdYlGn')
        accuracy = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
        plt.text(1, -3, 'Accuracy=%.2f' % accuracy, fontdict={'size': 20, 'color':  'red'})
        plt.text(1, -2, 'Epoch = %d ' % t, fontdict={'size': 20, 'color':  'blue'})
        plt.pause(0.5)

plt.ioff()
plt.show()