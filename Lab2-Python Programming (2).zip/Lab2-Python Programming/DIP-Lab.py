"""
===================================================
Digital Image Processing using OpenCV and Visualization by Matplotlib
===================================================
"""

import os
import cv2
import glob
import matplotlib.pyplot as plt
#########################################
# read image files of different formats
# imdir = 'path/to/files/'
# ext = ['png', 'jpg', 'gif']    # Add image formats here
# files = []
# [files.extend(glob.glob(imdir + '*.' + e)) for e in ext]
# images = [cv2.imread(file) for file in files]
#########################################


# Read images in a folder and resize each image to [224, 224] and save the resized image in the save_folder with the same file name
def load_images_from_folder1(folder, save_folder):
    images = []
    fig = plt.figure()
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))
        if img is not None:
            img_resized = cv2.resize(img, (224, 224), interpolation=cv2.INTER_AREA)
            plt.imshow(cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB))
            plt.pause(1)
            #write your code here
		
    return images


# Read all images in a folder and resize each image to [224, 224] and show the Original, Gray, Flipped Images
def load_images_from_folder2(folder):
    images = []
    fig = plt.figure()

    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))

        if img is not None:
            img_resized = cv2.resize(img, (224, 224), interpolation=cv2.INTER_AREA)
            fig.add_subplot(1, 3, 1)
            plt.imshow(cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB))
            plt.title("Original Color")
            fig.add_subplot(1, 3, 2)
            gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
            plt.imshow(gray, cmap='gray')
            plt.title("Gray")
            #write your code here
		
            plt.pause(1)
            images.append(img_resized)
    return images


# image PATH
PATH = './data/ants/'


#########################################
images1 = load_images_from_folder1(PATH, './data/output/')
#images2 = load_images_from_folder2(PATH)